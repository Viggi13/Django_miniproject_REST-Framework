from django.urls import path
from .api import DashboardCreateApi,DashboardListApi,DashboardUpdateApi,DashboardDeleteApi

urlpatterns=[
    path('api/',DashboardListApi.as_view()),
    path('api/update/<int:pk>',DashboardUpdateApi.as_view()),
    path('api/delete/<int:pk>',DashboardDeleteApi.as_view()),
    path('api/create',DashboardCreateApi.as_view()),
]