from rest_framework import generics

from rest_framework.response import Response

from .serializer import DashboardSerializer

from .models import Dashboard

class DashboardCreateApi(generics.CreateAPIView):
    queryset=Dashboard.objects.all()
    serializer_class =DashboardSerializer

class DashboardListApi(generics.ListAPIView):
    queryset=Dashboard.objects.all()
    serializer_class =DashboardSerializer

class DashboardUpdateApi(generics.RetrieveUpdateAPIView):
    queryset=Dashboard.objects.all()
    serializer_class =DashboardSerializer

class DashboardDeleteApi(generics.DestroyAPIView):
    queryset=Dashboard.objects.all()
    serializer_class =DashboardSerializer


