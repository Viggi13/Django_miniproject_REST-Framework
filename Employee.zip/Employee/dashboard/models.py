from django.db import models

# Create your models here.
class Dashboard(models.Model):
    empid=models.IntegerField()
    name=models.CharField(max_length=100)
    salary=models.IntegerField()
    dep=models.CharField(max_length=100)
    
